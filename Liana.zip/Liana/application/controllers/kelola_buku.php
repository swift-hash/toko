<?php

class Kelola_buku extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('model_barang');
    }

    public function index() {
        $data['barang'] = $this->model_barang->get_data()->result();
        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('kelola_buku', $data);
        $this->load->view('templates/footer');
    }

    public function tambah() {
        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('tambah');
        $this->load->view('templates/footer');
    }

    public function proses_tambah() { 
        $nama_brg = $this->input->post('nama_brg');
        $keterangan = $this->input->post('keterangan');
        $kategori = $this->input->post('kategori');
        $harga = $this->input->post('harga');
        $stok = $this->input->post('stok');

        $data = array(
            'nama_brg' => $nama_brg,
            'keterangan' => $keterangan,
            'kategori' => $kategori,
            'harga' => $harga,
            'stok' => $stok,
        );

        $this->model_barang->input_data($data, 'tb_barang');
        redirect('kelola_buku'); 
    }
}





