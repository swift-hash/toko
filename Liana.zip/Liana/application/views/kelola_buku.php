<main class="main users chart-page" id="skip-target">
                <div class="container">
                <div class="container mt-4">
    <h3>Daftar Barang</h3>
    <a href="<?php echo base_url('index.php/kelola_buku/tambah') ?>" class="btn btn-primary mb-3">Tambah Barang</a>
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Barang</th>
                <th>Keterangan</th>
                <th>Kategori</th>
                <th>Harga</th>
                <th>Stok</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $no = 1;
            foreach ($barang as $b) : ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><?= $b->nama_brg ?></td>
                    <td><?= $b->keterangan ?></td>
                    <td><?= $b->kategori ?></td>
                    <td><?= $b->harga ?></td>
                    <td><?= $b->stok ?></td>              
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
                </div>
            </main>

