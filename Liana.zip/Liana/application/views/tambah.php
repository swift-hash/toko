


      <main class="main users chart-page" id="skip-target">
                <div class="container">
                
                <form action="<?= base_url('index.php/kelola_buku/proses_tambah'); ?>" method="post" class="form">
                    <div class="mb-3">
                        <label for="nama_brg" class="form-label">Nama Barang</label>
                        <input type="text" name="nama_brg" class="form-control" id="nama_brg">
                    </div>
                    <div class="mb-3">
                        <label for="keterangan" class="form-label">Keterangan</label>
                        <input type="text" name="keterangan" class="form-control" id="keterangan">
                    </div>
                    <div class="mb-3">
                        <label for="kategori" class="form-label">Kategori</label>
                        <input type="text" name="kategori" class="form-control" id="kategori">
                        </div>
                    <div class="mb-3">
                        <label for="harga" class="form-label">Harga</label>
                        <input type="number" name="harga" class="form-control" id="harga" min="0">
                    </div>
                    <div class="mb-3">
                        <label for="stok" class="form-label">Stok</label>
                        <input type="number" name="stok" class="form-control" id="stok" min="0">
                    </div>
                    <button type="submit" class="btn btn-primary">Tambah</button>
                </form>

                </div>
            </main>