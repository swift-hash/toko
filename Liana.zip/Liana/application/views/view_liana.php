<!DOCTYPE html>
<html>
<head>
<title>view_liana</title>
</head>
<body>

<h1>Lianaa cntikk</h1>
<hr>
<p>Ngoding bukan soal hafal sintaks, tapi soal logika dan kesabaran.</p>

</body>
</html>