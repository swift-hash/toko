<footer class="footer">
                <div class="footer-start"></div>
                <div class="container footer--flex">
                    <p>2021 © Elegant Dashboard - <a href="https://elegant-dashboard.com">elegant-dashboard.com</a></p>
                </div>
            </footer>
        </div>
    </div>
    <script src="<?php echo base_url();?>assets/plugins/chart.min.js"></script>
    <script src="<?php echo base_url();?>assets/plugins/feather.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/script.js"></script>
</body>
</html>